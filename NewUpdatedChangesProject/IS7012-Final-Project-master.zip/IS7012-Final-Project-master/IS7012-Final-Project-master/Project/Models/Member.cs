﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Xml.Linq;

namespace Project.Models
{
    public class Member
    {
        public int Id { get; set; }

        [Required]
        [DisplayName("First Name")]
        public string FirstName { get; set; }

        [Required]
        [DisplayName("Last Name")]
        public string LastName { get; set; }

        [Required]
        [DisplayName("Student ID")]
        public string studentID { get; set; }

        [Required]
        [DisplayName("University")]
        public string University { get; set; }

        [Required]
        [DisplayName("Location")]
        public string Location { get; set; }

        [Required]
        [DisplayName("College")]
        public string College { get; set; }

        [Required]
        [DisplayName("Program")]
        public string Program { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:MM-dd-yyyy}", ApplyFormatInEditMode = true)]
        [DisplayName("Date Of Birth")]
        public DateTime DOB { get; set; }
        public int Age { get; set; }

        [DataType(DataType.PhoneNumber)]
        [DisplayName("Phone No")]
        public string PhoneNo { get; set; }

        [DisplayName("Email Address")]
        [Required(ErrorMessage = "The email address is required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int ZipCode { get; set; }

        public List<BookCheckoutHistory>? BookCheckoutHistorys { get; set; }
    }
}
