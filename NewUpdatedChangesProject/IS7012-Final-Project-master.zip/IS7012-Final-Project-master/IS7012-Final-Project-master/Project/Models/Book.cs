﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Project.Models
{
    public class Book
    {
        public int ID { get; set; }

        [Required]
        [DisplayName("Book Title")]
        public string Title { get; set; }

        [Required]
        [DisplayName("Author's Name")]
        public string AuthorName { get; set; }

        [Required]
        [DisplayName("Book ISBN")]
        public string ISBN { get; set; }

        [Required]
        [DisplayName("Copies")]
        public int Copies { get; set; }

        [DisplayName("Available?")]
        public int Availbility { get; set; }

        [DisplayName("Book Category")]
        public BookCategory? BookCategory { get; set; }
        
        public int? BookCategoryId { get; set; }

        public List<Author>? Authors { get; set; }

        public List<BookCheckoutHistory>? BookCheckoutHistorys { get; set; }
    }
}
