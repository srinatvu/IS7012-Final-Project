﻿using System.ComponentModel;

namespace Project.Models
{
    public class BookCategory
    {
        public int ID { get; set; }

        [DisplayName("Book Category")]
        public string Name { get; set; }

        public List<Book>? Books { get; set; }
        public List<Author>? Authors { get; set; }
        public List<BookCheckoutHistory>? BookCheckoutHistorys { get; set; }

    }
}
