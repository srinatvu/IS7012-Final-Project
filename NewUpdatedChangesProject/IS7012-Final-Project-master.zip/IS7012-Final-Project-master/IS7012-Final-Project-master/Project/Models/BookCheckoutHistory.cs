﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Xml.Linq;
using static System.Reflection.Metadata.BlobBuilder;

namespace Project.Models
{
    public class BookCheckoutHistory
    {
        public int ID { get; set; }
        public Member? Member { get; set; }
        [DisplayName("Borrower Student ID")]
        public int? MemberId { get; set; }

        [DisplayName("Borrower Last Name")]
        public int? MemberLastName { get; set; }

        [Required]
        [Display(Name = "Borrowed Location")]
        public string location { get; set; }
        public Book? Book { get; set; }
        [DisplayName("ISBN")]
        public int? BookISBN { get; set; }

        [DisplayName("Book Name")]
        public int? BookTitle { get; set; }

        public BookCategory? BookCategory { get; set; }
        [DisplayName("Book Category")]
        public int? BookCategoryName { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:MM-dd-yyyy}", ApplyFormatInEditMode = true)]
        [DisplayName("Borrow Date")]
        public DateTime Borrowdt { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:MM-dd-yyyy}", ApplyFormatInEditMode = true)]
        [DisplayName("Return Date")]
        public DateTime Returndt { get; set; }

        public Staff? Staff { get; set; }
        [DisplayName("Issued By")]
        public int? StaffEmpNo { get; set; }

        [DisplayName("Remaining Copies")]
        public int Avcopies { get; set; }
    }
}
