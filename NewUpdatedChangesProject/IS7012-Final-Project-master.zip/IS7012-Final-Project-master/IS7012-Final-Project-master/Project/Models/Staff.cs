﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace Project.Models
{
    public class Staff
    {
        public int ID { get; set; }

        [Required]
        [Display(Name = "Staff No")]
        public int EmpNo { get; set; }

        [Required]
        [Display(Name = "Staff First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Staff Last Name")]
        public string LastName { get; set; }

        public List<BookCheckoutHistory>? BookCheckoutHistorys { get; set; }
    }
}
