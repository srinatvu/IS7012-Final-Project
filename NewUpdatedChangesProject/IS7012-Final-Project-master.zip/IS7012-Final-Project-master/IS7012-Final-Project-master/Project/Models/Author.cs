﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class Author
    {
        public int ID { get; set; }

        [Required]
        [Display(Name = "Author First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Author Last Name")]
        public string LastName { get; set; }

        [Required]
        [Display(Name = "ISBN")]
        public string ISBN { get; set; }

        public BookCategory? BookCategory { get; set; }
        [DisplayName("Book Category")]
        public int? BookCategoryId { get; set; }

        public Book? Book { get; set; }
        [DisplayName("Book Title")]
        public int? BookId { get; set; }

    }
}
