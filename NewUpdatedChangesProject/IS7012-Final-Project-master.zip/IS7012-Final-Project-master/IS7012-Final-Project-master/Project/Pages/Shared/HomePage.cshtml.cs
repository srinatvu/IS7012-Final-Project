using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Project.Pages.Shared
{
    public class HomePageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
