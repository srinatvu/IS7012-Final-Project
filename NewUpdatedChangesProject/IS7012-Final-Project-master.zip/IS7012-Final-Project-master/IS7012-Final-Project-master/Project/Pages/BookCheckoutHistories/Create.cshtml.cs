﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Project.Data;
using Project.Models;

namespace Project.Pages.BookCheckoutHistories
{
    public class CreateModel : PageModel
    {
        private readonly Project.Data.ProjectContext _context;

        public CreateModel(Project.Data.ProjectContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            ViewData["MemberStudentID"] = new SelectList(_context.Member, "Id", "studentID");
            ViewData["MemberStudentLastName"] = new SelectList(_context.Member, "Id", "LastName");
            ViewData["BookStudentTitle"] = new SelectList(_context.Book, "ID", "Title");
            ViewData["BookStudentCategory"] = new SelectList(_context.BookCategory, "ID", "Name");
            ViewData["IssuedBy"] = new SelectList(_context.Staff, "ID", "EmpNo");
            return Page();
        }

        [BindProperty]
        public BookCheckoutHistory BookCheckoutHistory { get; set; }
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
          if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.BookCheckoutHistory.Add(BookCheckoutHistory);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
